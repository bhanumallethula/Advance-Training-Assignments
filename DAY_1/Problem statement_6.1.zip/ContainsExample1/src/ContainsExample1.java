import java.util.ArrayList;
public class ContainsExample1 {
   public static void main(String[] args) {

      ArrayList<String> student = new ArrayList<String>();
      student.add("Bhavani");
      student.add("Srilekha");
      student.add("Akansha");
      student.add("Hariharan");

      System.out.println("ArrayList contains the string 'Bhavani': "
                                           +student.contains("Bhavani"));
      System.out.println("ArrayList contains the string 'Srilekha': "
                                             +student.contains("Sri"));
      System.out.println("ArrayList contains the string 'Akansha': "
                                          +student.contains("Akansha"));
      System.out.println("ArrayList contains the string 'Hariharan': "
                                           +student.contains("hari"));

      ArrayList<Integer> student2 = new ArrayList<Integer>();
      student2.add(1);
      student2.add(99);
      student2.add(56);
      student2.add(13);
      student2.add(44);
      student2.add(6);

      System.out.println("'1' is present in arraylist: "+student2.contains(1));
      System.out.println("'55' is present in arraylist: "+student2.contains(55));
      System.out.println("'44' is there in arraylist: "+student2.contains(44));
      System.out.println("'7' is there in arraylist: "+student2.contains(7));
   }
}
